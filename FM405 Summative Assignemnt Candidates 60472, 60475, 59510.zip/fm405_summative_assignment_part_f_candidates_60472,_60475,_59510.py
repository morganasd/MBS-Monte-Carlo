# -*- coding: utf-8 -*-
"""FM405 Summative Assignment Part f Candidates 60472, 60475, 59510


# =============================================================================
# FM405 SUMMATIVE - FILE 4: PART (f) EXTENDED PREPAYMENT MODEL
#
# Replaces the binary optimal-stopping rule from part (e) with a
# logistic CPR model incorporating three economic mechanisms:
#
#   1. REFINANCING INCENTIVE (Inc): borrowers prepay faster when
#      the mortgage rate exceeds prevailing market rates.
#      Inc_i^s = r_WAC - r_i^s  (rate gap, in decimal)
#
#   2. SEASONING (Sea): newly originated mortgages have low prepayment
#      that ramps up over the first 5 years (10 semi-annual periods).
#      Sea_i = min(i/10, 1)
#
#   3. BURNOUT (BO): borrowers who have already had many opportunities
#      to refinance but did not are less likely to prepay in future.
#      BO_i^s = sum_{tau=0}^{i-1} max(r_WAC - r_tau^s, 0) * delta
#      (cumulative in-the-money exposure along path s)
#
# CPR MODEL (logistic, calibrated to Berger et al. 2021 / US mortgage data):
#
#   CPR_i^s = C_max / (1 + exp(-(-3.17 + 197*Inc + 3.10*Sea - 51*BO)))
#
#   Parameters:
#     C_max = 0.30  (ceiling: CPR cannot exceed 30% p.a.)
#     alpha = -3.17 (intercept: newborn, ATM, no burnout -> CPR ~1.2%)
#     beta1 = 197   (incentive sensitivity: 100bps ITM multiplies CPR ~1.8x)
#     beta2 = 3.10  (seasoning lift: fully seasoned pool prepays ~12x faster)
#     beta3 = 51    (burnout suppression: 5yr 200bps exposure floors CPR ~7%)
#
# CPR -> SMM conversion (semi-annual step delta=0.5):
#   SMM_i^s = 1 - (1 - CPR_i^s)^delta
#
# Prepayment decision: draw U ~ U(0,1); prepay if U < SMM_i^s
#
# Note: Run File 1, File 2, and File 3 first.
# =============================================================================

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq

# =============================================================================
# PARAMETERS
# =============================================================================

# Logistic CPR model parameters (Berger et al. 2021)
C_MAX  =  0.30    # CPR ceiling
ALPHA  = -3.17    # intercept
BETA1  =  197.0   # refinancing incentive sensitivity
BETA2  =  3.10    # seasoning coefficient
BETA3  =  51.0    # burnout suppression coefficient

# Simulation parameters
N_sim_f = 100000
seed_f  = 44      # independent from parts (d) and (e)

# WAC = BDT par mortgage rate from part (b)
r_WAC = c_BDT     # weighted average coupon (continuously compounded, decimal)

print("=" * 70)
print("PART (f): EXTENDED PREPAYMENT MODEL — LOGISTIC CPR")
print("=" * 70)
print()
print(f"  CPR model: logistic with incentive, seasoning, burnout")
print(f"  C_max = {C_MAX:.2f}  alpha = {ALPHA:.2f}  beta1 = {BETA1:.0f}"
      f"  beta2 = {BETA2:.2f}  beta3 = {BETA3:.0f}")
print(f"  r_WAC (BDT c*) = {r_WAC*100:.4f}%")
print(f"  N simulations  = {N_sim_f:,}")

# =============================================================================
# RANDOM DRAWS — independent stream
# =============================================================================

rng_f         = np.random.default_rng(seed_f)
up_moves_f    = rng_f.uniform(size=(N_sim_f, N)) < 0.5
prepay_draws  = rng_f.uniform(size=(N_sim_f, N))   # for SMM comparison

# =============================================================================
# CPR / SMM FUNCTIONS
# =============================================================================

def compute_cpr(inc, sea, bo,
                c_max=C_MAX, alpha=ALPHA,
                beta1=BETA1, beta2=BETA2, beta3=BETA3):
    """
    Logistic CPR model.

    Parameters
    ----------
    inc   : refinancing incentive = r_WAC - r  (decimal, e.g. 0.01 = 1%)
    sea   : seasoning index = min(i/10, 1)
    bo    : burnout = cumulative past ITM exposure (decimal * periods)

    Returns
    -------
    CPR   : annual conditional prepayment rate (decimal)
    """
    logit = alpha + beta1 * inc + beta2 * sea - beta3 * bo
    return c_max / (1.0 + np.exp(-logit))


def cpr_to_smm(cpr, delta=0.5):
    """
    Convert annual CPR to semi-annual single monthly mortality (SMM).
    SMM = 1 - (1 - CPR)^delta
    """
    return 1.0 - (1.0 - cpr) ** delta


# =============================================================================
# PART (f) MONTE CARLO VALUATION
# =============================================================================

def mc_mortgage_f(r_tree, bal, c, delta, N, N_sim,
                  up_moves, prepay_draws, r_WAC,
                  c_max=C_MAX, alpha=ALPHA,
                  beta1=BETA1, beta2=BETA2, beta3=BETA3):
    """
    Value the mortgage along BDT paths using the logistic CPR prepayment model.

    At each period i >= 1:
      1. Compute refinancing incentive: Inc = r_WAC - r_tree[i][j]
      2. Compute seasoning:             Sea = min(i/10, 1)
      3. Compute burnout:               BO  = cumulative past ITM exposure
      4. Compute CPR via logistic model
      5. Convert CPR -> SMM (semi-annual probability)
      6. Draw U ~ U(0,1); prepay if U < SMM
         - Prepay:    pv += cum_disc * bal[i];  break
         - No prepay: pv += cum_disc * disc * pmt;  update burnout

    Cash flow discounting mirrors part (e):
      - pmt discounted by cum_disc * disc (end-of-period cash flow)
      - bal[i] discounted by cum_disc only (value at start of period i)
    """
    pmt      = coupon_payment(c, delta, N)
    pv_paths = np.zeros(N_sim)

    for sim in range(N_sim):
        j        = 0
        cum_disc = 1.0
        pv       = 0.0
        bo       = 0.0    # burnout accumulator for this path

        for i in range(N):
            r    = r_tree[i][j]
            disc = np.exp(-r * delta)

            if i > 0:
                # --- Three factors ---
                inc = r_WAC - r                        # refinancing incentive
                sea = min(i / 10.0, 1.0)              # seasoning
                # bo already accumulated from previous periods

                # --- CPR and SMM ---
                cpr = compute_cpr(inc, sea, bo,
                                  c_max, alpha, beta1, beta2, beta3)
                smm = cpr_to_smm(cpr, delta)

                # --- Prepayment decision ---
                if prepay_draws[sim, i] < smm:
                    pv += cum_disc * bal[i]
                    break

            # --- No prepayment: receive pmt at end of period i ---
            pv       += cum_disc * disc * pmt
            cum_disc *= disc

            # --- Update burnout: add ITM exposure this period ---
            bo += max(r_WAC - r, 0.0) * delta

            # --- Advance node ---
            if not up_moves[sim, i]:
                j += 1

        pv_paths[sim] = pv

    return pv_paths


# =============================================================================
# STEP 1: VALUE MORTGAGE UNDER EXTENDED MODEL AT BDT PAR RATE
# =============================================================================

print()
print("-" * 70)
print("Step 1: Mortgage value at BDT par rate c* under extended prepayment")
print("-" * 70)

pv_f = mc_mortgage_f(
    r_tree_BDT, bal_BDT, c_BDT, delta, N, N_sim_f,
    up_moves_f, prepay_draws, r_WAC
)

mc_mean_f  = pv_f.mean()
mc_se_f    = pv_f.std() / np.sqrt(N_sim_f)
ci_lo_f    = mc_mean_f - 1.96 * mc_se_f
ci_hi_f    = mc_mean_f + 1.96 * mc_se_f

print(f"\n  At c* = {c_BDT*100:.4f}% (BDT par rate from part b):")
print(f"  {'Point estimate':<35}: £{mc_mean_f:.6f}")
print(f"  {'Standard error':<35}: £{mc_se_f:.6f}")
print(f"  {'95% CI':<35}: [£{ci_lo_f:.6f}, £{ci_hi_f:.6f}]")
print(f"  {'Part (e) tree value':<35}: £{results['BDT']['V'][0][0]:.6f}")
print()
print(f"  Interpretation: under realistic prepayment the mortgage is worth")
print(f"  £{mc_mean_f:.4f} rather than £100.00, so c* must be adjusted upward")
print(f"  to compensate UBS for the additional prepayment risk.")

# =============================================================================
# STEP 2: FIND NEW PAR RATE c** UNDER EXTENDED MODEL
# =============================================================================

print()
print("-" * 70)
print("Step 2: Find new par rate c** under extended prepayment model")
print("-" * 70)
print("  Root-finding: search c** such that MC mortgage price = £100")
print("  (Brent's method, same approach as part (a) calibration)")


# Use a small fixed simulation for root-finding only (fast)
# Then re-evaluate at full N_sim_f once c** is found
N_sim_root = 10_000
rng_root   = np.random.default_rng(seed_f + 10)
up_root    = rng_root.uniform(size=(N_sim_root, N)) < 0.5
pd_root    = rng_root.uniform(size=(N_sim_root, N))

def mortgage_price_fast(c_try):
    """Fast MC price using fixed 10,000-path draws for root-finding."""
    bal_try, _, _, _ = amortisation_schedule(c_try, delta, N)
    pv_try = mc_mortgage_f(
        r_tree_BDT, bal_try, c_try, delta, N, N_sim_root,
        up_root, pd_root, r_WAC
    )
    return pv_try.mean() - 100.0

# We know from Step 1 that price at c_BDT (~4.73%) > 100
# At a high rate like 12% price will be well below 100 — bracket is valid
print(f"\n  Bracket check:")
p_lo = mortgage_price_fast(0.03) + 100
p_hi = mortgage_price_fast(0.12) + 100
print(f"  Price at c=3.00%: £{p_lo:.4f}")
print(f"  Price at c=12.0%: £{p_hi:.4f}")
print(f"  Valid bracket: {'YES' if p_lo > 100 > p_hi else 'NO'}")

c_star_f = brentq(mortgage_price_fast, 0.03, 0.12, xtol=1e-5)
print(f"\n  Root found at c** = {c_star_f*100:.4f}% (fast MC, 10,000 paths)")

# Verify at full 100,000 paths
bal_f_check, _, _, _ = amortisation_schedule(c_star_f, delta, N)
pv_check = mc_mortgage_f(
    r_tree_BDT, bal_f_check, c_star_f, delta, N, N_sim_f,
    up_moves_f, prepay_draws, r_WAC
)
print(f"  Verification at N=100,000: £{pv_check.mean():.6f} "
      f"(SE = £{pv_check.std()/np.sqrt(N_sim_f):.6f})")

print(f"\n  New par rate c** = {c_star_f*100:.4f}%")
print(f"  BDT par rate c*  = {c_BDT*100:.4f}%")
print(f"  Increase         = {(c_star_f - c_BDT)*10000:.2f} bp")
print(f"  Interpretation: UBS must charge {(c_star_f-c_BDT)*10000:.1f}bp more")
print(f"  to break even under realistic prepayment behaviour.")

# =============================================================================
# STEP 3: MBS PRICING UNDER EXTENDED MODEL
# =============================================================================

print()
print("-" * 70)
print("Step 3: MBS pricing under extended prepayment model")
print("-" * 70)

# Pass-through rate = c** - 50bp
c_pt_f   = c_star_f - 0.005
bal_f, _, _, pmt_f = amortisation_schedule(c_star_f, delta, N)
rp_f     = np.exp(c_star_f * delta) - 1    # periodic mortgage rate
rp_pt_f  = np.exp(c_pt_f   * delta) - 1    # periodic pass-through rate

print(f"\n  New par rate c**          = {c_star_f*100:.4f}%")
print(f"  Pass-through rate c**-50bp = {c_pt_f*100:.4f}%")

def mc_mbs_f(r_tree, bal, c_mort, c_pt, delta, N, N_sim,
             up_moves, prepay_draws, r_WAC,
             c_max=C_MAX, alpha=ALPHA,
             beta1=BETA1, beta2=BETA2, beta3=BETA3):
    """
    Price PT, IO, and PO tranches under extended prepayment model.

    Cash flow split at each period i:
      - Interest to IO  = bal[i] * rp_pt   (pass-through coupon on balance)
      - Principal to PO = pmt - bal[i]*rp_m (scheduled amortisation)
      - On prepayment:
          PO receives bal[i] (outstanding principal)
          IO receives nothing (coupon stream terminates)
          PT = IO + PO receives bal[i]
    """
    pmt_mort = coupon_payment(c_mort, delta, N)
    rp_m     = np.exp(c_mort * delta) - 1
    rp_pt_   = np.exp(c_pt   * delta) - 1

    pv_PT = np.zeros(N_sim)
    pv_PO = np.zeros(N_sim)
    pv_IO = np.zeros(N_sim)

    for sim in range(N_sim):
        j        = 0
        cum_disc = 1.0
        bo       = 0.0

        for i in range(N):
            r    = r_tree[i][j]
            disc = np.exp(-r * delta)

            # Cash flow components at period i
            interest_pt = bal[i] * rp_pt_          # IO coupon
            principal   = pmt_mort - bal[i] * rp_m  # PO scheduled principal

            if i > 0:
                inc = r_WAC - r
                sea = min(i / 10.0, 1.0)
                cpr = compute_cpr(inc, sea, bo,
                                  c_max, alpha, beta1, beta2, beta3)
                smm = cpr_to_smm(cpr, delta)

                if prepay_draws[sim, i] < smm:
                    # Prepayment: PO and PT receive outstanding principal
                    # IO receives nothing (coupon stream ends)
                    pv_PT[sim] += cum_disc * bal[i]
                    pv_PO[sim] += cum_disc * bal[i]
                    break

            # No prepayment: scheduled cash flows
            pv_PT[sim] += cum_disc * disc * (interest_pt + principal)
            pv_PO[sim] += cum_disc * disc * principal
            pv_IO[sim] += cum_disc * disc * interest_pt
            cum_disc   *= disc

            # Update burnout
            bo += max(r_WAC - r, 0.0) * delta

            if not up_moves[sim, i]:
                j += 1

    return pv_PT, pv_PO, pv_IO


pv_PT_f, pv_PO_f, pv_IO_f = mc_mbs_f(
    r_tree_BDT, bal_f, c_star_f, c_pt_f,
    delta, N, N_sim_f, up_moves_f, prepay_draws, r_WAC
)

def ci(pv):
    m  = pv.mean()
    se = pv.std() / np.sqrt(len(pv))
    return m, se, m - 1.96*se, m + 1.96*se

pt_m, pt_se, pt_lo, pt_hi = ci(pv_PT_f)
po_m, po_se, po_lo, po_hi = ci(pv_PO_f)
io_m, io_se, io_lo, io_hi = ci(pv_IO_f)

print(f"\n  {'Security':<6}  {'Price (£)':>12}  {'Std Error':>12}  {'95% CI':>28}")
print(f"  {'-'*6}  {'-'*12}  {'-'*12}  {'-'*28}")
print(f"  {'PT':<6}  {pt_m:>12.6f}  {pt_se:>12.6f}"
      f"  [{pt_lo:.6f}, {pt_hi:.6f}]")
print(f"  {'PO':<6}  {po_m:>12.6f}  {po_se:>12.6f}"
      f"  [{po_lo:.6f}, {po_hi:.6f}]")
print(f"  {'IO':<6}  {io_m:>12.6f}  {io_se:>12.6f}"
      f"  [{io_lo:.6f}, {io_hi:.6f}]")
print(f"\n  Consistency check: PT = IO + PO = "
      f"£{io_m + po_m:.6f}  (PT = £{pt_m:.6f})")

# Compare to part (c) binary model
print(f"\n  Comparison with part (c) binary prepayment model (BDT):")
print(f"  {'Security':<6}  {'Part (c)':>12}  {'Part (f)':>12}  {'Change (bp)':>12}")
print(f"  {'-'*6}  {'-'*12}  {'-'*12}  {'-'*12}")
for sec, pf, label in [
    ('PT', pt_m, 'PT'), ('PO', po_m, 'PO'), ('IO', io_m, 'IO')
]:
    pc = mbs_results['BDT'][sec][0][0]
    print(f"  {sec:<6}  {pc:>12.4f}  {pf:>12.4f}  {(pf-pc)*100:>+12.2f}")

# =============================================================================
# STEP 4: SENSITIVITY ANALYSIS
# =============================================================================

print()
print("-" * 70)
print("Step 4: Sensitivity analysis")
print("-" * 70)

def quick_price(beta1_try, beta2_try, beta3_try):
    """Quick MC price at c_BDT with alternative parameters."""
    pv = mc_mortgage_f(
        r_tree_BDT, bal_BDT, c_BDT, delta, N, N_sim_f,
        up_moves_f, prepay_draws, r_WAC,
        c_max=C_MAX, alpha=ALPHA,
        beta1=beta1_try, beta2=beta2_try, beta3=beta3_try
    )
    return pv.mean(), pv.std() / np.sqrt(N_sim_f)

print(f"\n  Base case: beta1={BETA1:.0f}, beta2={BETA2:.2f}, beta3={BETA3:.0f}")
print(f"  {'Scenario':<35}  {'Price (£)':>12}  {'Std Error':>12}")
print(f"  {'-'*35}  {'-'*12}  {'-'*12}")

scenarios = [
    ('Base case',                BETA1,       BETA2,      BETA3),
    ('High incentive (b1=300)',  300,         BETA2,      BETA3),
    ('Low incentive (b1=100)',   100,         BETA2,      BETA3),
    ('No seasoning (b2=0)',      BETA1,       0.0,        BETA3),
    ('High seasoning (b2=6)',    BETA1,       6.0,        BETA3),
    ('No burnout (b3=0)',        BETA1,       BETA2,      0.0),
    ('High burnout (b3=100)',    BETA1,       BETA2,      100.0),
]

for label, b1, b2, b3 in scenarios:
    m, se = quick_price(b1, b2, b3)
    print(f"  {label:<35}  {m:>12.6f}  {se:>12.6f}")

# =============================================================================
# FIGURES
# =============================================================================

# --- Figure F1: CPR surface across rate gap and seasoning ---
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle(
    "Figure F1 — Part (f): Logistic CPR Model\n"
    "Conditional Prepayment Rate as a function of incentive and seasoning",
    fontsize=11, fontweight='bold'
)

rate_gaps = np.linspace(-0.03, 0.05, 200)   # -3% to +5% rate gap
seasons   = [0.0, 0.25, 0.50, 0.75, 1.0]
bo_fixed  = 0.0

for sea in seasons:
    cprs = [compute_cpr(g, sea, bo_fixed) * 100 for g in rate_gaps]
    axes[0].plot(rate_gaps * 100, cprs,
                 label=f'Sea = {sea:.2f}', linewidth=1.5)

axes[0].axvline(0, color='grey', linewidth=0.8, linestyle=':')
axes[0].set_xlabel('Rate Gap = r_WAC − r (%, decimal)')
axes[0].set_ylabel('CPR (% per year)')
axes[0].set_title('CPR vs Incentive at different Seasoning levels\n(Burnout = 0)')
axes[0].legend(fontsize=8)
axes[0].grid(axis='y', color='#eee', linewidth=0.5)
axes[0].set_ylim(0, 32)

burnouts = [0.0, 0.05, 0.10, 0.20, 0.40]
sea_fixed = 1.0

for bo in burnouts:
    cprs = [compute_cpr(g, sea_fixed, bo) * 100 for g in rate_gaps]
    axes[1].plot(rate_gaps * 100, cprs,
                 label=f'BO = {bo:.2f}', linewidth=1.5)

axes[1].axvline(0, color='grey', linewidth=0.8, linestyle=':')
axes[1].set_xlabel('Rate Gap = r_WAC − r (%)')
axes[1].set_ylabel('CPR (% per year)')
axes[1].set_title('CPR vs Incentive at different Burnout levels\n(Seasoning = 1.0)')
axes[1].legend(fontsize=8)
axes[1].grid(axis='y', color='#eee', linewidth=0.5)
axes[1].set_ylim(0, 32)

plt.tight_layout()
plt.savefig('figF1_cpr_model.png', dpi=150, bbox_inches='tight')
plt.show()
print("\n  Figure F1 saved.")

# --- Figure F2: PV distribution comparison (e) vs (f) ---
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle(
    "Figure F2 — Part (f): Mortgage PV Distribution\n"
    "Binary prepayment (part e) vs Logistic CPR prepayment (part f)",
    fontsize=11, fontweight='bold'
)

axes[0].hist(pv_BDT, bins=80, color='darkorange', edgecolor='none',
             alpha=0.8, density=True, label='Part (e) binary')
axes[0].axvline(pv_BDT.mean(), color='black', linestyle='--', linewidth=1.5,
                label=f'Mean = £{pv_BDT.mean():.4f}')
axes[0].axvline(100, color='red', linestyle=':', linewidth=1.2, label='Par = £100')
axes[0].set_title('Part (e): Binary Optimal Prepayment')
axes[0].set_xlabel('Discounted PV (£)')
axes[0].set_ylabel('Density')
axes[0].legend(fontsize=8)

axes[1].hist(pv_f, bins=80, color='steelblue', edgecolor='none',
             alpha=0.8, density=True, label='Part (f) logistic CPR')
axes[1].axvline(pv_f.mean(), color='black', linestyle='--', linewidth=1.5,
                label=f'Mean = £{pv_f.mean():.4f}')
axes[1].axvline(100, color='red', linestyle=':', linewidth=1.2, label='Par = £100')
axes[1].set_title('Part (f): Logistic CPR Prepayment')
axes[1].set_xlabel('Discounted PV (£)')
axes[1].set_ylabel('Density')
axes[1].legend(fontsize=8)

plt.tight_layout()
plt.savefig('figF2_pv_comparison.png', dpi=150, bbox_inches='tight')
plt.show()
print("  Figure F2 saved.")

# --- Figure F3: MBS tranche prices comparison ---
fig, ax = plt.subplots(figsize=(10, 5))
fig.suptitle(
    "Figure F3 — Part (f): MBS Tranche Prices\n"
    "Binary prepayment (part c) vs Logistic CPR (part f)",
    fontsize=11, fontweight='bold'
)

securities = ['PT', 'PO', 'IO']
prices_c   = [mbs_results['BDT'][s][0][0] for s in securities]
prices_f   = [pt_m, po_m, io_m]
errors_f   = [pt_se * 1.96, po_se * 1.96, io_se * 1.96]

x = np.arange(3)
w = 0.32
ax.bar(x - w/2, prices_c, w, color='darkorange', alpha=0.85,
       label='Part (c) binary', edgecolor='white')
ax.bar(x + w/2, prices_f, w, color='steelblue',  alpha=0.85,
       label='Part (f) logistic CPR', edgecolor='white',
       yerr=errors_f, capsize=4, error_kw={'linewidth': 1.2})

ax.set_xticks(x)
ax.set_xticklabels(['Pass-Through (PT)', 'Principal Only (PO)',
                    'Interest Only (IO)'])
ax.set_ylabel('Price (£ per £100)')
ax.axhline(100, color='green', linewidth=0.8, linestyle=':', label='Par')
ax.legend(fontsize=9)
ax.grid(axis='y', color='#eee', linewidth=0.5)
ax.set_ylim(0, 115)

for i, (pc, pf) in enumerate(zip(prices_c, prices_f)):
    ax.text(i - w/2, pc + 0.5, f'£{pc:.2f}', ha='center', fontsize=8)
    ax.text(i + w/2, pf + 0.5, f'£{pf:.2f}', ha='center', fontsize=8)

plt.tight_layout()
plt.savefig('figF3_mbs_comparison.png', dpi=150, bbox_inches='tight')
plt.show()
print("  Figure F3 saved.")

# --- Figure F4: Sample CPR paths ---
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle(
    "Figure F4 — Part (f): Sample CPR Paths\n"
    "CPR evolution along 200 simulated BDT paths",
    fontsize=11, fontweight='bold'
)

# Recompute CPR along first 200 paths for illustration
cpr_paths  = np.zeros((200, N))
bo_paths   = np.zeros((200, N))

for sim in range(200):
    j  = 0
    bo = 0.0
    for i in range(N):
        r   = r_tree_BDT[i][j]
        inc = r_WAC - r
        sea = min(i / 10.0, 1.0)
        cpr_paths[sim, i]  = compute_cpr(inc, sea, bo) * 100
        bo_paths[sim, i]   = bo
        bo += max(r_WAC - r, 0.0) * delta
        if not up_moves_f[sim, i]:
            j += 1

t_grid_f = np.arange(N) * delta + delta

for k in range(200):
    axes[0].plot(t_grid_f, cpr_paths[k], color='steelblue',
                 alpha=0.05, linewidth=0.5)
axes[0].plot(t_grid_f, cpr_paths.mean(axis=0), color='navy',
             linewidth=2, label='Mean CPR')
axes[0].set_xlabel('Years')
axes[0].set_ylabel('CPR (% per year)')
axes[0].set_title('CPR Paths Across Simulations')
axes[0].legend(fontsize=8)
axes[0].grid(axis='y', color='#eee', linewidth=0.5)

for k in range(200):
    axes[1].plot(t_grid_f, bo_paths[k], color='darkorange',
                 alpha=0.05, linewidth=0.5)
axes[1].plot(t_grid_f, bo_paths.mean(axis=0), color='darkred',
             linewidth=2, label='Mean Burnout')
axes[1].set_xlabel('Years')
axes[1].set_ylabel('Cumulative Burnout (BO)')
axes[1].set_title('Burnout Accumulation Across Simulations')
axes[1].legend(fontsize=8)
axes[1].grid(axis='y', color='#eee', linewidth=0.5)

plt.tight_layout()
plt.savefig('figF4_cpr_paths.png', dpi=150, bbox_inches='tight')
plt.show()
print("  Figure F4 saved.")

# =============================================================================
# SUMMARY
# =============================================================================

print()
print("=" * 70)
print("PART (f) SUMMARY")
print("=" * 70)
print()
print(f"  Prepayment model: logistic CPR with three factors")
print(f"    1. Refinancing incentive (beta1 = {BETA1:.0f})")
print(f"    2. Seasoning            (beta2 = {BETA2:.2f})")
print(f"    3. Burnout              (beta3 = {BETA3:.0f})")
print()
print(f"  Mortgage pricing:")
print(f"    Part (b) binary c*  = {c_BDT*100:.4f}%")
print(f"    Part (f) logistic c** = {c_star_f*100:.4f}%")
print(f"    Additional spread     = {(c_star_f-c_BDT)*10000:.2f} bp")
print()
print(f"  MBS prices (part f, c** - 50bp pass-through rate):")
print(f"    PT = £{pt_m:.4f}  [{pt_lo:.4f}, {pt_hi:.4f}]")
print(f"    PO = £{po_m:.4f}  [{po_lo:.4f}, {po_hi:.4f}]")
print(f"    IO = £{io_m:.4f}  [{io_lo:.4f}, {io_hi:.4f}]")
print(f"    PT = IO + PO check: £{io_m+po_m:.4f}")