# -*- coding: utf-8 -*-
"""FM405 Summative Assignment Part A code candidates 60472, 60475, 59510


# =============================================================================
# FM405 SUMMATIVE - FILE 1: INTEREST RATE TREE CALIBRATION
# Parts (a): Ho-Lee and BDT Interest Rate Tree Calibration
# Data: Bank of England Nominal Spot Curve, 30 January 2026
# Note: Run all files on one document since later parts require outputs from
# earlier parts
# =============================================================================

import numpy as np
from scipy.optimize import brentq

# =============================================================================
# MARKET DATA
# =============================================================================

delta = 0.5   # semi-annual steps
N     = 20    # 20 steps = 10 years

# Bank of England nominal spot rates (%), 30 January 2026
spot_rates = {
    0.5:  3.48, 1.0:  3.55, 1.5:  3.59, 2.0:  3.63, 2.5:  3.67,
    3.0:  3.72, 3.5:  3.78, 4.0:  3.84, 4.5:  3.90, 5.0:  3.97,
    5.5:  4.04, 6.0:  4.11, 6.5:  4.18, 7.0:  4.25, 7.5:  4.31,
    8.0:  4.38, 8.5:  4.45, 9.0:  4.51, 9.5:  4.57, 10.0: 4.63
}

# Zero coupon bond prices per £100 face value
P = {}
for k, (maturity, rate) in enumerate(spot_rates.items(), start=1):
    P[k] = 100 * np.exp(-(rate / 100) * maturity)

# =============================================================================
# HO-LEE CALIBRATION
# Normal (additive) model: r_{i+1,j} = r_{i,j} + theta_i*delta +/- sigma*sqrt(delta)
# =============================================================================

sigma_HL = 68.02 / 10000    # 68.02 bp/yr normal vol -> 0.006802

r0_HL       = -np.log(P[1] / 100) / delta
r_tree_HL   = np.zeros((N + 1, N + 1))
r_tree_HL[0][0] = r0_HL
q_HL        = np.zeros((N + 1, N + 1))
q_HL[0][0]  = 1.0
theta_HL    = np.zeros(N)

for i in range(N - 1):
    target = P[i + 2]

    def bond_price_given_theta_HL(theta_i, i=i):
        bottom_next = r_tree_HL[i][i] + theta_i * delta - sigma_HL * np.sqrt(delta)
        q_next = np.zeros(i + 2)
        for j in range(i + 2):
            val = 0.0
            if j <= i:
                r_ij = r_tree_HL[i][i] + (i - j) * 2 * sigma_HL * np.sqrt(delta)
                val += 0.5 * q_HL[i][j] * np.exp(-r_ij * delta)
            if j >= 1 and (j - 1) <= i:
                r_ij1 = r_tree_HL[i][i] + (i - (j - 1)) * 2 * sigma_HL * np.sqrt(delta)
                val += 0.5 * q_HL[i][j - 1] * np.exp(-r_ij1 * delta)
            q_next[j] = val
        price = 0.0
        for j in range(i + 2):
            r_next_j = bottom_next + (i + 1 - j) * 2 * sigma_HL * np.sqrt(delta)
            price += q_next[j] * np.exp(-r_next_j * delta) * 100
        return price

    theta_HL[i] = brentq(
        lambda th: bond_price_given_theta_HL(th) - target, -2.0, 5.0
    )

    bottom_next = r_tree_HL[i][i] + theta_HL[i] * delta - sigma_HL * np.sqrt(delta)
    for j in range(i + 2):
        r_tree_HL[i + 1][j] = bottom_next + (i + 1 - j) * 2 * sigma_HL * np.sqrt(delta)

    for j in range(i + 2):
        val = 0.0
        if j <= i:
            r_ij = r_tree_HL[i][i] + (i - j) * 2 * sigma_HL * np.sqrt(delta)
            val += 0.5 * q_HL[i][j] * np.exp(-r_ij * delta)
        if j >= 1 and (j - 1) <= i:
            r_ij1 = r_tree_HL[i][i] + (i - (j - 1)) * 2 * sigma_HL * np.sqrt(delta)
            val += 0.5 * q_HL[i][j - 1] * np.exp(-r_ij1 * delta)
        q_HL[i + 1][j] = val

# Fill final column
bottom_N_HL = r_tree_HL[N - 1][N - 1] + theta_HL[N - 2] * delta - sigma_HL * np.sqrt(delta)
for j in range(N + 1):
    r_tree_HL[N][j] = bottom_N_HL + (N - j) * 2 * sigma_HL * np.sqrt(delta)

# --- Print Ho-Lee tree -------------------------------------------------------
W = 7
print("=" * (8 + W * (N + 1)))
print("Table: The Risk Neutral Ho-Lee Interest Rate Tree")
print(f"BoE Nominal Spot Curve, 30 Jan 2026 | sigma = {sigma_HL*100:.4f}% | delta = {delta} | N = {N}")
print("=" * (8 + W * (N + 1)))

print(f"{'Time T':>8}", end="")
for i in range(N + 1):
    print(f"{i * delta:>{W}.1f}", end="")
print()

print(f"{'Period i':>8}", end="")
for i in range(N + 1):
    print(f"{i:>{W}d}", end="")
print()

print(f"{'θi(×100)':>8}", end="")
print(f"{'':>{W}}", end="")
for i in range(N):
    if i <= N - 2:
        print(f"{theta_HL[i] * 100:>{W}.4f}", end="")
    else:
        print(f"{'':>{W}}", end="")
print()
print()

for j in range(N + 1):
    print(f"{'j='+str(j):>8}", end="")
    for i in range(N + 1):
        if j <= i:
            print(f"{r_tree_HL[i][j] * 100:>{W}.2f}", end="")
        else:
            print(f"{'':>{W}}", end="")
    print()

print()
print("=" * 55)
print("Ho-Lee Calibration Check")
print("=" * 55)
print(f"{'k':>4}  {'Maturity':>10}  {'Market':>10}  {'Model':>10}  {'Diff':>10}")
for k in range(1, N + 1):
    maturity = k * delta
    market   = P[k]
    if k < N:
        model = sum(q_HL[k][j] for j in range(k + 1)) * 100
    else:
        model = sum(
            q_HL[N-1][j] * np.exp(-r_tree_HL[N-1][j] * delta)
            for j in range(N)
        ) * 100
    diff = model - market
    flag = "  *last step" if k == N else ""
    print(f"{k:>4}  {maturity:>10.1f}  {market:>10.4f}  {model:>10.4f}  {diff:>10.6f}{flag}")

# =============================================================================
# BDT CALIBRATION
# Lognormal model: log(r_{i+1,j}) = log(r_{i,j}) + theta_i*delta +/- sigma*sqrt(delta)
# =============================================================================

sigma_BDT = 16.23 / 100     # 16.23% Black vol -> 0.1623

r0_BDT      = -np.log(P[1] / 100) / delta
z0_BDT      = np.log(r0_BDT)

z_tree_BDT  = np.zeros((N + 1, N + 1))
r_tree_BDT  = np.zeros((N + 1, N + 1))
z_tree_BDT[0][0] = z0_BDT
r_tree_BDT[0][0] = r0_BDT

q_BDT       = np.zeros((N + 1, N + 1))
q_BDT[0][0] = 1.0
theta_BDT   = np.zeros(N)

for i in range(N - 1):
    target = P[i + 2]

    def bond_price_given_theta_BDT(theta_i, i=i):
        z_bottom_next = z_tree_BDT[i][i] + theta_i * delta - sigma_BDT * np.sqrt(delta)
        q_next = np.zeros(i + 2)
        for j in range(i + 2):
            val = 0.0
            if j <= i:
                r_ij = np.exp(z_tree_BDT[i][i] + (i - j) * 2 * sigma_BDT * np.sqrt(delta))
                val += 0.5 * q_BDT[i][j] * np.exp(-r_ij * delta)
            if j >= 1 and (j - 1) <= i:
                r_ij1 = np.exp(z_tree_BDT[i][i] + (i - (j - 1)) * 2 * sigma_BDT * np.sqrt(delta))
                val += 0.5 * q_BDT[i][j - 1] * np.exp(-r_ij1 * delta)
            q_next[j] = val
        price = 0.0
        for j in range(i + 2):
            z_next_j = z_bottom_next + (i + 1 - j) * 2 * sigma_BDT * np.sqrt(delta)
            r_next_j = np.exp(z_next_j)
            price += q_next[j] * np.exp(-r_next_j * delta) * 100
        return price

    theta_BDT[i] = brentq(
        lambda th: bond_price_given_theta_BDT(th) - target, -5.0, 10.0
    )

    z_bottom_next = z_tree_BDT[i][i] + theta_BDT[i] * delta - sigma_BDT * np.sqrt(delta)
    for j in range(i + 2):
        z_tree_BDT[i + 1][j] = z_bottom_next + (i + 1 - j) * 2 * sigma_BDT * np.sqrt(delta)
        r_tree_BDT[i + 1][j] = np.exp(z_tree_BDT[i + 1][j])

    for j in range(i + 2):
        val = 0.0
        if j <= i:
            r_ij = np.exp(z_tree_BDT[i][i] + (i - j) * 2 * sigma_BDT * np.sqrt(delta))
            val += 0.5 * q_BDT[i][j] * np.exp(-r_ij * delta)
        if j >= 1 and (j - 1) <= i:
            r_ij1 = np.exp(z_tree_BDT[i][i] + (i - (j - 1)) * 2 * sigma_BDT * np.sqrt(delta))
            val += 0.5 * q_BDT[i][j - 1] * np.exp(-r_ij1 * delta)
        q_BDT[i + 1][j] = val

# Fill final column
z_bottom_N_BDT = z_tree_BDT[N - 1][N - 1] + theta_BDT[N - 2] * delta - sigma_BDT * np.sqrt(delta)
for j in range(N + 1):
    z_tree_BDT[N][j] = z_bottom_N_BDT + (N - j) * 2 * sigma_BDT * np.sqrt(delta)
    r_tree_BDT[N][j] = np.exp(z_tree_BDT[N][j])

# --- Print BDT tree ----------------------------------------------------------
print()
print("=" * (8 + W * (N + 1)))
print("Table: The Risk Neutral BDT Interest Rate Tree")
print(f"BoE Nominal Spot Curve, 30 Jan 2026 | sigma = {sigma_BDT*100:.4f}% | delta = {delta} | N = {N}")
print("=" * (8 + W * (N + 1)))

print(f"{'Time T':>8}", end="")
for i in range(N + 1):
    print(f"{i * delta:>{W}.1f}", end="")
print()

print(f"{'Period i':>8}", end="")
for i in range(N + 1):
    print(f"{i:>{W}d}", end="")
print()

print(f"{'θi(×100)':>8}", end="")
print(f"{'':>{W}}", end="")
for i in range(N):
    if i <= N - 2:
        print(f"{theta_BDT[i] * 100:>{W}.4f}", end="")
    else:
        print(f"{'':>{W}}", end="")
print()
print()

for j in range(N + 1):
    print(f"{'j='+str(j):>8}", end="")
    for i in range(N + 1):
        if j <= i:
            print(f"{r_tree_BDT[i][j] * 100:>{W}.2f}", end="")
        else:
            print(f"{'':>{W}}", end="")
    print()

print()
print("=" * 55)
print("BDT Calibration Check")
print("=" * 55)
print(f"{'k':>4}  {'Maturity':>10}  {'Market':>10}  {'Model':>10}  {'Diff':>10}")
for k in range(1, N + 1):
    maturity = k * delta
    market   = P[k]
    if k < N:
        model = sum(q_BDT[k][j] for j in range(k + 1)) * 100
    else:
        model = sum(
            q_BDT[N-1][j] * np.exp(-r_tree_BDT[N-1][j] * delta)
            for j in range(N)
        ) * 100
    diff = model - market
    flag = "  *last step" if k == N else ""
    print(f"{k:>4}  {maturity:>10.1f}  {market:>10.4f}  {model:>10.4f}  {diff:>10.6f}{flag}")

print(f"\nMinimum rate in BDT tree: {np.min(r_tree_BDT[r_tree_BDT > 0]) * 100:.4f}%")
print(f"Maximum rate in BDT tree: {np.max(r_tree_BDT) * 100:.4f}%")